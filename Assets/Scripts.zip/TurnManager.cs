using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    public GridManager gridManager;
    public PrefabSpawner prefabSpawner;

    private bool isSylphTurn;
    private bool isCharacterTurn;

    private Sylph sylph;
    private int charactersPlaced = 0;
    private List<CharacterBase> characters = new List<CharacterBase>();
    private List<CharacterBase> activeCharacters = new List<CharacterBase>();
    private int currentCharacterIndex = 0;

    void Awake()
    {
        gridManager.GenerateGrid();
        gridManager.SpawnSylph();
        StartStage();

        isSylphTurn = false;
        isCharacterTurn = false;
    }

    void Start()
    {
        sylph = FindObjectOfType<Sylph>();
    }

    private void Update()
    {
        if (isCharacterTurn && Input.GetKeyDown(KeyCode.Q))
        {
            EndCharacterTurn();
        }
    }

    public void OnCharacterPlaced(CharacterBase character)
    {
        charactersPlaced++;
        activeCharacters.Add(character);
        Debug.Log($"ĳ���� ��ġ �Ϸ�: ���� {charactersPlaced}�� ��ġ��");

        if (charactersPlaced >= 4)
        {
            Debug.Log("��� ĳ���� ��ġ �Ϸ�, ������ �� ����");
            gridManager.ResetGridColors();
            StartSylphTurn();
        }
    }

    private void StartStage()
    {
        sylph = gridManager.sylphInstance;
    }

    private void StartSylphTurn()
    {
        characters.AddRange(FindObjectsOfType<CharacterBase>());
        Debug.Log("���� �̵� �� ����");

        sylph.ClearEncounteredCharacters();
        sylph.SetControllable(true);
        sylph.SylphTurn();
        isSylphTurn = true;
    }

    public void EndSylphTurn()
    {
        sylph.SetControllable(false);
        isSylphTurn = false;
        Debug.Log("���� �� ����");

        sylph.ClearActivatedCells();

        activeCharacters = sylph.GetEncounteredCharacters();
        if (activeCharacters.Count > 0)
        {
            currentCharacterIndex = 0;
            StartCharacterTurn();
        }
        else
        {
            Debug.Log("����ģ ĳ���Ͱ� ���� ���� �����մϴ�.");
            ResetTurn();
        }
    }

    public void StartCharacterTurn()
    {
        if (currentCharacterIndex < activeCharacters.Count)
        {
            CharacterBase character = activeCharacters[currentCharacterIndex];

            character.SetTurn(true);
            Debug.Log($"{character.name}�� ���� ���۵˴ϴ�.");
            isCharacterTurn = true;
        }
        else
        {
            Debug.Log("��� ĳ���� �� ����");
            StartCoroutine(MoveAllCharactersSequentially());
        }
    }

    public void EndCharacterTurn()
    {
        if (currentCharacterIndex < activeCharacters.Count)
        {
            CharacterBase character = activeCharacters[currentCharacterIndex];
            character.SetTurn(false);
            Debug.Log($"{character.name}�� ���� ����˴ϴ�.");
        }

        currentCharacterIndex++;
        if (currentCharacterIndex < activeCharacters.Count)
        {
            StartCharacterTurn();
        }
        else
        {
            StartCoroutine(MoveAllCharactersSequentially());
        }
    }

    private IEnumerator MoveAllCharactersSequentially()
    {
        foreach (CharacterBase character in activeCharacters)
        {
            yield return StartCoroutine(character.StartMovement());
        }
        isCharacterTurn = false;
        Debug.Log("��� ĳ������ �̵��� �Ϸ�Ǿ����ϴ�.");
        ResetTurn();
    }

    public void ResetTurn()
    {
        gridManager.ClearActivatedCells();
        EnemyTurn();
    }

    public void EnemyTurn()
    {
        Debug.Log("�� ���� ���۵˴ϴ�.");
        StartSylphTurn();
    }
}
