using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Button endTurnButton; // UI ��ư ����
    public Sylph sylph; // Sylph ��ü ����

}
