using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magician : CharacterBase
{
    // Start is called before the first frame update
    protected override void Start()
    {
        base.Start(); // �θ� Ŭ������ Start �޼��� ȣ��

    }

    // Update�� �ʿ� ������ �θ� Ŭ������ ���� ����մϴ�.
    protected override void Update()
    {
        base.Update(); // �θ� Ŭ������ Update ȣ��
    }
    public virtual IEnumerator StartMovement()
    {
        foreach (Vector2Int cellPosition in activatedCells)
        {
            Vector3 targetPosition = gridManager.GetWorldPositionFromGrid(cellPosition);
            Vector3 direction = (targetPosition - transform.position).normalized;
            Quaternion targetRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));

            while (Quaternion.Angle(transform.rotation, targetRotation) > 0.1f)
            {
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * 30);
                yield return null;
            }

            while (Vector3.Distance(transform.position, targetPosition) > 0.1f)
            {
                transform.position = Vector3.MoveTowards(transform.position, targetPosition, Time.deltaTime * 10);
                yield return null;
            }

            gridManager.UpdateCharacterPosition(this, cellPosition);
            yield return new WaitForSeconds(0.1f);
        }

        activatedCells.Clear();
        ClearPathIndicators();
        Debug.Log($"{name}�� �̵��� �Ϸ�Ǿ����ϴ�.");
        // ���� ���¿� ���� �ܼ� �޽��� ���
        if (mana >= 8)
        {
            Debug.Log("���׿�!");
        }
        else if (mana >= 4 && mana <= 7)
        {
            Debug.Log("���̾~");
        }
        else if (mana >= 0 && mana <= 3)
        {
            Debug.Log("�̾�!...");
        }
    }
}
